package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edit03;
    private EditText edit04;
    private Button button05;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit03 = findViewById(R.id.edit03);
        edit04 = findViewById(R.id.edit04);
        button05 = findViewById(R.id.button05);
        button05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edit04.getText().toString();
                String password = edit03.getText().toString();
                if (email.equals("sharmeen@gmail.com") && password.equals("123")){
                    Intent myIntent = new Intent(MainActivity.this, navigatepage.class);
                    startActivity(myIntent);
                }
                else {
                    Toast.makeText(MainActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}